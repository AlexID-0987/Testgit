﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    
    public class Ars
    {
        public delegate void Member();
        int[] arr = new int[] { 2, 5, 7, 66, 32, 67, 45, 545, 34 };

        public void mas()
        {
            Array.Sort(arr, (int a, int b) => b - a);
            foreach(var a in arr)
            {
                Console.Write($" { a}");
            }
            Console.WriteLine();
        }
        
        public void Num()
        {

            Console.WriteLine($"Hello");
            Console.WriteLine($"Enter number - ");
            int rez = int.Parse(Console.ReadLine());
            Console.WriteLine($"You number {rez}");
            Array.IndexOf(arr, (rez));

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == rez)
                {
                    Console.WriteLine($"Number yes");

                }
                else
                {
                    Console.WriteLine($"Number NOT");
                }
            }
        }
    }
}
