﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Delegate
{
    

    class Program
    {
        
        public static void Main(string[] args)
        {
            
            Ars de = new Ars();
            de.mas();
            Ars.Member der = new Ars.Member(de.Num);
            der.Invoke();
            
        }
    }
}
