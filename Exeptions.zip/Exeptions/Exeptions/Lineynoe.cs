﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exeptions
{
   
    class Lineynoe
    {

        
        public static double Urav (double a,double b,double c,double x)
        {
           
            try
            {
                double reshenie = (c-(a*x))/b;
                return reshenie;
            }
            catch(DivideByZeroException e) 
            {
                Console.WriteLine($"Kooficient: {e.Message}");
                throw;
            }
        }
        
    }
}
