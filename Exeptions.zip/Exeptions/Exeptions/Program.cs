﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exeptions
{
    
  

    class Program
    {
        
        static void Main(string[] args)
        {

            Console.WriteLine("Enter coefficient 1 ->");
            double a = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter coefficient 2 ->");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter x ->");
            double x = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter rezultat ->");
            double c = double.Parse(Console.ReadLine());

            try
            {
                Console.WriteLine($"Uravnenie = {a}*{x}+{b}*y={c}");
                double reshenie = c-(a*x);
                double reshenie1 = reshenie / b;
                Console.WriteLine($"Y ={reshenie1}");
                Console.WriteLine($"result={Lineynoe.Urav(a, b,c,x)}");
                Console.WriteLine($"Uravnenie = {a}*{x}+{b}*{reshenie1}={c}");




            }



            catch (DivideByZeroException e) when (e.InnerException==null)
            {
                Console.WriteLine($"Zero: {e}");
            }
            catch(FormatException e)
            {
                Console.WriteLine($"Format: {e.Source}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                Console.WriteLine("Finally");
            }
        }
       

    }
}
