--use valute

--create table Items (
--Id int not null identity,
--Price int  NOT NULL,
--currency nvarchar(50) NOT NULL)
--insert into Items(price,currency) values(100,'USD')
--insert into Items(price,currency) values(10,'EUR')
--insert into Items(price,currency) values(20,'USD')
--insert into Items(price,currency) values(40,'USD')
--insert into Items(price,currency) values(20,'EUR')
--insert into Items(price,currency) values(30,'UAH')
--insert into Items(price,currency) values(400,'USD')
--insert into Items(price,currency) values(50,'EUR')
--insert into Items(price,currency) values(60,'USD')

--select  * from Items

--create table rates (
--currency nvarchar(50) NOT NULL,
--date date NOT NULL,
--rate int not null)

--insert into rates (currency,date,rate) values('USD','10.01.2015',25.3)
--insert into rates (currency,date,rate) values('USD','11.01.2015',25.3)
--insert into rates (currency,date,rate) values('USD','17.01.2015',25.3)
--insert into rates (currency,date,rate) values('USD','13.01.2015',25.5)
--insert into rates (currency,date,rate) values('EUR','17.01.2015',29.4)
--insert into rates (currency,date,rate) values('EUR','11.01.2015',29.4)
--insert into rates (currency,date,rate) values('UAH','11.01.2015',1)

--select  * from rates

--select max (date)
--from rates
 
select I.Price, r.rate 
from Items as I inner join rates as r on r.currency=I.currency
where I.currency='UAH'
update Items
set Price=Price*1
where currency='UAH'

--create procedure sp_price as
--select I.Price, r.rate 
--from Items as I inner join rates as r on r.currency=I.currency
--where I.currency='UAH'and I.Price=I.Price*r.rate

--exec sp_price



 --create trigger tg_price on Items
 --after update 
 --as 
 --print('Update price')
 --update Items
 --set Price=Price*1
 --where currency='UAH'

 