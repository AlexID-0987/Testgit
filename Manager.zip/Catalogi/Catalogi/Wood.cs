﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Media;

namespace Catalogi
{

    class Wood
    {
        
        

        //public void Ca()
        //{


        //    string dir = "D";
        //    string dir_a = "C";
        //    Console.WriteLine($"Enter Directory: D");
        //    string rez=Console.ReadLine();
        //    if (dir == rez)
        //    {
        //        string create = "Create", delete = "Delete";
        //        Console.WriteLine($"To Create or Delete");
        //        string rez_a = Console.ReadLine();
        //        if(rez_a==create)
        //        {
        //            Console.WriteLine($"Enter name file");
        //            string name = Console.ReadLine();
        //            string createDirectory = @"D:"+name;

        //            try
        //            {
        //                Directory.CreateDirectory(createDirectory);
        //            }
        //            catch (Exception e)
        //            {
        //                Console.WriteLine(e.Message);
        //            }
        //        }
        //        else if(rez_a==delete)
        //        {
        //            Console.WriteLine($"Enter name delite file");
        //            string name_a = Console.ReadLine();
        //            string deleteDirectory = "D:"+name_a;

        //            try
        //            {
        //                Directory.Delete(deleteDirectory);
        //            }
        //            catch (Exception e)
        //            {
        //                Console.WriteLine(e.Message);
        //            }
        //        }
        //        else
        //        {
        //            Console.WriteLine($"Not command!Nice musical bonus!)))");
        //            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Expert\source\repos\Catalogi\Mavve - Merry Christmas.wav");
        //            player.Play();
        //            Console.ReadKey();


        //        }
        //        List<string> Wood = Directory.GetDirectories("D:\\").ToList();
        //        { }
        //        foreach (var wod in Wood)
        //        {
        //            Console.WriteLine($"Disk " + wod);

        //        }
        //        Console.WriteLine();
        //        //int activeWoods = 0;
        //        ////while (true)
        //        //{
        //        //   // Console.Clear();
        //        //    for (int i = 0; i < Wood.Count; i++)
        //        //    {
        //        //        if (i == activeWoods)
        //        //        {
        //        //            Console.BackgroundColor = ConsoleColor.Blue;
        //        //            Console.ForegroundColor = ConsoleColor.Green;
        //        //        }
        //        //        Console.WriteLine($"Disk " + Wood[i]);
        //        //        Console.ResetColor();

        //        //    }
        //        //    ConsoleKeyInfo key = Console.ReadKey();
        //        //    if (key.Key == ConsoleKey.DownArrow)
        //        //        activeWoods++;
        //        //    else
        //        //        activeWoods--;
        //        //   // break;

        //        // }

        //        Console.WriteLine();
        //    }
        //    else if(rez==dir_a)
        //    {
        //        List<string> Wood = Directory.GetDirectories("C:\\").ToList();
        //        { }
        //        foreach (var wod in Wood)
        //        {
        //            Console.WriteLine($"Disk " + wod);

        //        }
        //        Console.WriteLine();
        //    }
        //    else
        //    {
        //        Console.WriteLine($"Sorry!!! Not directory!");
        //    }
           
        //}
        
        //public void Catal()
        //{
        //    List<string> Wood = Directory.GetFiles("D:Maistat\\").ToList();
        //    { }
        //    foreach (var wod in Wood)
        //    {
        //        Console.WriteLine($"Disk " + wod);

        //    }
        //    Console.WriteLine();
        //}
        //public void Move()
        //{
        //    string sourceDirectory = @"D:\Yes";
        //    string destinationDirectory = @"D:\Not";

        //    try
        //    {
        //        Directory.Move(sourceDirectory, destinationDirectory);
                
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }
            
        //}
        //public void ShowWindowsDirectoryInfo()
        //{
        //    DirectoryInfo dir = new DirectoryInfo("D:\\Maistat");
        //    Console.WriteLine("***** Информация о каталоге *****\n");
        //    Console.WriteLine("Полный путь: {0}\nНазвание папки: {1}\nРодительский каталог: {2}\n" +
        //                 "Время создания: {3}\nАтрибуты: {4}\nКорневой каталог: {5}",
        //                 dir.FullName, dir.Name, dir.Parent, dir.CreationTime, dir.Attributes, dir.Root);

        //    Console.WriteLine();
        //}

        ////public void Create()
        ////{

        ////    string createDirectory = @"D:\Main Foto";

        ////    try
        ////    {
        ////        Directory.CreateDirectory(createDirectory);
        ////    }
        ////    catch (Exception e)
        ////    {
        ////        Console.WriteLine(e.Message);
        ////    }
        ////}
        //public void Delete()
        //{

        //    string deleteDirectory = "D:\\Main Foto";

        //    try
        //    {
        //        Directory.Delete(deleteDirectory);
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }
        //}
        //public void Copy()
        //{

        //    string path = @"D:\Copy\Copy.jnt";
        //    string newPath = @"D:\Copy\Text.jnt";
        //    FileInfo fileInf = new FileInfo(path);
        //    if (fileInf.Exists)
        //    {
        //        fileInf.CopyTo(newPath, true);
                
        //    }
        //    else
        //    {
        //        Console.WriteLine($"Not file!!!");
        //    }
           
        //}
        //public  void CreateTextAsync()
        //{

        //    string writePath = @"D:\Copy\hta.txt";

        //    string text = "Привет мир!\nПока мир ehfgthtrfd...";
        //    try
        //    {
        //        using (StreamWriter sw = new StreamWriter(writePath, false, System.Text.Encoding.Default))
        //        {
        //            sw.WriteLine(text);
        //        }

        //        using (StreamWriter sw = new StreamWriter(writePath, true, System.Text.Encoding.Default))
        //        {
        //            sw.WriteLine("Дозапись");
                    
        //        }
        //        Console.WriteLine("Запись выполнена");
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //    }

            

        //}
        public void Terminal()
        {
            string command;

            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Green;
            ShowResult("Microsoft Terminal ver" + DateTime.Now.ToLongDateString());
            Console.WriteLine($"Help - Comands.");

            ShowMessage();
            do
            {
                command = Console.ReadLine();
                switch (command)
                {
                    case "Date":
                        ShowResult(DateTime.Now.ToLongDateString());
                        ShowMessage();
                        break;
                    case "":
                        ShowMessage();
                        break;
                    case "create":
                        string createDirectory = @"D:\Main Day";

                        try
                        {
                            Directory.CreateDirectory(createDirectory);
                            Console.WriteLine($"File create!");
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        ShowMessage();
                        break;
                    case "Move":
                        
                        
                            string sourceDirectory = @"D:\Yes";
                            string destinationDirectory = @"D:\Not";


                            try
                            {
                                Directory.Move(sourceDirectory, destinationDirectory);

                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                        ShowMessage();
                            break;
                    case "Catal":
                        List<string> Wood = Directory.GetFiles("D:Maistat\\").ToList();
                        { }
                        foreach (var wod in Wood)
                        {
                            Console.WriteLine($"Disk " + wod);

                        }
                        Console.WriteLine();
                        ShowMessage();
                        break;
                    case "Copy":
                        string path = @"D:\Copy\Copy.jnt";
                        string newPath = @"D:\Copy\Text.jnt";
                        FileInfo fileInf = new FileInfo(path);
                        if (fileInf.Exists)
                        {
                            fileInf.CopyTo(newPath, true);

                        }
                        else
                        {
                            Console.WriteLine($"Not file!!!");
                        }
                        ShowMessage();
                        break;
                    case "Help":
                        Console.WriteLine($"Enter commands:\nCopy\nCatal-catalogi\nCreate" +
                            $"\nMove\nDate\nDelete\nText-Create text documetns\nInforms-Informations of file," +
                            $"\nClear\nCreate Catal-Create Catalogi");
                        break;
                    case "Delete":
                        string deleteDirectory = "D:\\Main Foto";

                        try
                        {
                            Directory.Delete(deleteDirectory);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        ShowMessage();
                        break;
                    case "Text":

                        string writePath = @"D:\Copy\hta.txt";

                        string text = "Create File...";
                        try
                        {
                            using (StreamWriter sw = new StreamWriter(writePath, false, System.Text.Encoding.Default))
                            {
                                sw.WriteLine(text);
                            }

                            using (StreamWriter sw = new StreamWriter(writePath, true, System.Text.Encoding.Default))
                            {
                                sw.WriteLine("and text!!!");

                            }
                            Console.WriteLine("Recording completed!!!");
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                    case "Informs":
                        DirectoryInfo dir = new DirectoryInfo("D:\\Maistat");
                        Console.WriteLine("***** Informations on catalogi *****\n");
                        Console.WriteLine("The path to the file: {0}\nName file: {1}\nParent directory: {2}\n" +
                                     "Time create: {3}\nAtribut: {4}\nCatalogi: {5}",
                                     dir.FullName, dir.Name, dir.Parent, dir.CreationTime, dir.Attributes, dir.Root);

                        Console.WriteLine();
                        break;
                    case "Clear":
                        Console.Clear();
                        
                        break;
                    case "Create Catal":
                        string dir_b = "D";
                        string dir_a = "C";
                        Console.WriteLine($"Enter Directory: D");
                        string rez = Console.ReadLine();
                        if (dir_b == rez)
                        {
                            string create = "Create", delete = "Delete";
                            Console.WriteLine($"To Create or Delete");
                            string rez_a = Console.ReadLine();
                            if (rez_a == create)
                            {
                                Console.WriteLine($"Enter name file");
                                string name = Console.ReadLine();
                                string createsDirectory = @"D:" + name;

                                try
                                {
                                    Directory.CreateDirectory(createsDirectory);
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                }
                            }
                            else if (rez_a == delete)
                            {
                                Console.WriteLine($"Enter name delite file");
                                string name_a = Console.ReadLine();
                                string deletesDirectory = "D:" + name_a;

                                try
                                {
                                    Directory.Delete(deletesDirectory);
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Not command!Nice musical bonus!)))");
                                System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Expert\source\repos\Catalogi\Mavve - Merry Christmas.wav");
                                player.Play();
                                Console.ReadKey();


                            }
                            
                            Console.WriteLine();
                        }
                        else if (rez == dir_a)
                        {
                            List<string> Woods = Directory.GetDirectories("C:\\").ToList();
                            { }
                            foreach (var wod in Woods)
                            {
                                Console.WriteLine($"Disk " + wod);

                            }
                            Console.WriteLine();
                        }
                        else
                        {
                            Console.WriteLine($"Sorry!!! Not directory!");
                        }

                
                            break;
                    case "Exit":
                        return;
                        
                    default:
                        ShowResult("ERROR: Unknow command");

                        break;
                }
            }
            while (command != "quit");
        }
        public void ShowMessage(string message = "")
        {
            Console.Write(":>" + message);
        }
        public void ShowResult(string message = "")
        {
            Console.Write("\t" + message + "\n");
        }
        
    }

}
