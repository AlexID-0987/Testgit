﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Catalogi
{
    class Program
    {
        static void Main(string[] args)
        {

            Wood wo = new Wood();
           // wo.Ca();
           // wo.Catal();
           // wo.ShowWindowsDirectoryInfo();
           // wo.Move();
           //// wo.Create();
           // wo.Delete();
           // wo.Copy();
           // wo.CreateTextAsync();
            wo.Terminal();
            wo.ShowMessage();
            wo.ShowResult();

            
            

        }

    }
}
