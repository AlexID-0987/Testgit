--1
--create procedure sp_product as
--select F.Id,F.Brend,F.ProductId,B.Id,B.Brend,B.ProductId,C.Id,C.Brend,C.ProductId
--from  Footwears as F,Blouses as B,Costumes as C

--execute sp_product 
--2
--create procedure sp_footwear as
--select Brend,Price,Manufacturer,Products.Date
--from Footwears
--join Products on Products.Id = Footwears.ProductId


--exec sp_footwear
--3



--create procedure sp_custom as
--select top 3 Id,Name,Type,Money
--from Customers
--order by Date


--exec sp_custom
--4

--create procedure sp_seller as
--select Name,Date
--from Sellers as S
--where Money = (select max (Money) from Sellers)

--exec sp_seller
--5
--create procedure sp_brend as
--select P.Date,P.Id,P.Quantity,F.Brend
--from Products as P,Footwears as F
--where F.Brend ='Nike'

--exec sp_brend


--create procedure sp_nike 
--@name varchar(25) output
--as 
--select @name=f.Brend
--from Footwears f
--where f.Brend ='Nike'
--go
--declare @name varchar(25)
--exec sp_nike @name output
--select 'Yes:',@name
--6

--create procedure sp_customes as
--select *
--from Customers
--where Type =(select max (Type) from Customers)

--exec sp_customes
--7
--create procedure sp_customers as
--select Id,Name,Date
--from Customers
--where  Customers.Date > '10-08-2020 12:34:00' 

--exec sp_customers

--create procedure sp_delete as
--delete Customers
--where Date > '10-08-2020 12:34:00'

--exec sp_delete

