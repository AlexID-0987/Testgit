--use Musiccolection
--1
--create procedure sp_disk as
--select * 
--from Disks

--exec sp_disk
--2
--create procedure sp_name as
--select *
--from Disks
--where Name = 'Acvarium'

--exec sp_name
--3
--create procedure sp_stile as
--select top 1 Style
--from Pesnia
--join Disks on Disks.Id=Pesnia.PerformerId

--exec sp_stile
--4
--create procedure sp_disks as
--select top (1) Quantity,Name
--from Disks

--exec sp_disks
--5
--create procedure sp_delete as
--delete Pesnia
--where Style = 'ROC'

--exec sp_delete
--6
--7
--create procedure sp_deletedisk as
--delete Disks
--where Name = 'San'

--exec sp_deletedisk
