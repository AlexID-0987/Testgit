--select * from Duers_view  

--create view Duers_view as
--select Name,Date,Many
--from Duyers
--where Many = (select max (Many) from Duyers)
--6
--select *from Sellers_max_view

--create view Sellers_max_view as
--select Name,Surname,Sales 
--from Sellers
--where Sales = (select max (Sales) from Sellers)

--5
--select *from Work_shops_view

--create view Work_shops_view as
--select Sellers.Name+' '+Sellers.Surname as [Name],Sales,Duyers.Name as [Duyers],Date , Many
--from Sellers,Duyers
--4
--select *from Duyers_view

--create view Duyers_view as
--select * 
--from Products



--3

--select *from Products_view

--insert into Products(Coming,Consuption,Date,AssortmentsId) 
--values(21.00,4.00,'2020-12-02',4)

--create view Products_view as
--select Consuption,p.Date,Name
--from Products as p, Assortments
--where Name='Apple' 


--2
--select *from Duyers_view
--insert into Duyers (Name,Date,Many)
--values ('Gala','2015-23-12',93.00)

--create view Duyers_view as
--select Name,Date,Many
--from Duyers

--1
--select *from Sellers_view
--insert into Sellers (Name , Surname,Sales,ProductId)
--values ('Ilon', 'Mask',1000000.000,9)
--insert into Sellers (Name , Surname,Sales,ProductId)
--values ('Dina', 'Dares',330.000,8) 
--create view Sellers_view as
--select Name+' '+Surname as Name,Id
--from Sellers
--use sales
