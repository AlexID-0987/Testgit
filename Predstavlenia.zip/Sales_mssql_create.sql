CREATE TABLE [Sellers] (
	Id int NOT NULL identity,
	Name nvarchar(50) NOT NULL,
	Surname nvarchar(50) NOT NULL,
	Sales money NOT NULL,
	ProductId int NOT NULL,
  CONSTRAINT [PK_SELLERS] PRIMARY KEY CLUSTERED
  (
  [Id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
insert into Sellers(Name,Surname,Sales,ProductId) values('Nataly','Friz',30.000,2)
insert into Sellers(Name,Surname,Sales,ProductId) values('Mary','Gan',543.000,1)
insert into Sellers(Name,Surname,Sales,ProductId) values('Alex','Dombras',34.000,7)
insert into Sellers(Name,Surname,Sales,ProductId) values('Ivan','Coco',12,8)
insert into Sellers(Name,Surname,Sales,ProductId) values('Nicolas','Fero',560.000,8)

select  * from Sellers

CREATE TABLE [Duyers] (
	Id int NOT NULL identity,
	Name nvarchar(50) NOT NULL,
	Date datetime NOT NULL,
	Many money NOT NULL,
  CONSTRAINT [PK_DUYERS] PRIMARY KEY CLUSTERED
  (
  [Id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO

insert into Duyers(Name,Date,Many) values('Miho','2020-04-01',2.000)
insert into Duyers(Name,Date,Many) values('Nico','2020-03-06',1.000)
insert into Duyers(Name,Date,Many) values('Ann','2020-01-11',1.600)
insert into Duyers(Name,Date,Many) values('Lia','2020-11-03',250.00)
insert into Duyers(Name,Date,Many) values('Dshek','2020-09-10',50)

select  * from Duyers

CREATE TABLE [Products] (
	Id int NOT NULL identity,
	Coming int NOT NULL,
	Consuption int NOT NULL,
	Date datetime NOT NULL,
	AssortmentsId int NOT NULL,
  CONSTRAINT [PK_PRODUCTS] PRIMARY KEY CLUSTERED
  (
  [Id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO

insert into Products(Coming,Consuption,Date,AssortmentsId) values(50.00,10.00,'2020-16-12',2)
insert into Products(Coming,Consuption,Date,AssortmentsId) values(100.00,90.00,'2020-03-02',3)
insert into Products(Coming,Consuption,Date,AssortmentsId) values(13.00,10.00,'2020-15-04',5)
insert into Products(Coming,Consuption,Date,AssortmentsId) values(7.00,1.00,'2019-11-07',7)
insert into Products(Coming,Consuption,Date,AssortmentsId) values(5.00,10.00,'2018-02-12',2)

select  * from Products

CREATE TABLE [Assortments] (
	Id int NOT NULL identity,
	Name nvarchar(50) NOT NULL,
	Date datetime NOT NULL,
	Weight int NOT NULL,
	DuyesId int NOT NULL,
  CONSTRAINT [PK_ASSORTMENTS] PRIMARY KEY CLUSTERED
  (
  [Id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO

insert into Assortments(Name,Date,Weight,DuyesId) values('Apple','2020-12-08',30.00,2)
insert into Assortments(Name,Date,Weight,DuyesId) values('Pug','2018-06-08',130.00,4)
insert into Assortments(Name,Date,Weight,DuyesId) values('Bread','2020-12-11',200.00,6)
insert into Assortments(Name,Date,Weight,DuyesId) values('Chocolade','2020-06-08',7.00,5)
insert into Assortments(Name,Date,Weight,DuyesId) values('Milk','2020-12-12',23.00,1)

select  * from Assortments

ALTER TABLE [Sellers] WITH CHECK ADD CONSTRAINT [Sellers_fk0] FOREIGN KEY ([ProductId]) REFERENCES [Products]([Id])
--ON UPDATE CASCADE
GO
ALTER TABLE [Sellers] CHECK CONSTRAINT [Sellers_fk0]
GO


ALTER TABLE [Products] WITH CHECK ADD CONSTRAINT [Products_fk0] FOREIGN KEY ([AssortmentsId]) REFERENCES [Assortments]([Id])
--ON UPDATE CASCADE
GO
ALTER TABLE [Products] CHECK CONSTRAINT [Products_fk0]
GO

ALTER TABLE [Assortments] WITH CHECK ADD CONSTRAINT [Assortments_fk0] FOREIGN KEY ([DuyesId]) REFERENCES [Duyers]([Id])
--ON UPDATE CASCADE
GO
ALTER TABLE [Assortments] CHECK CONSTRAINT [Assortments_fk0]
GO

