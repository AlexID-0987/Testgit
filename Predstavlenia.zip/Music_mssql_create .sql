CREATE TABLE [Performers] (
	Id int NOT NULL identity,
	Name nvarchar(50) NOT NULL,
	Surname nvarchar(50) NOT NULL,
  CONSTRAINT [PK_PERFORMERS] PRIMARY KEY CLUSTERED
  (
  [Id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
insert into Performers(Name,Surname) values('Michael','Jackson')
insert into Performers(Name,Surname) values('Muse','Musev')
insert into Performers(Name,Surname) values('Chuck','berry')
insert into Performers(Name,Surname) values('Fillip','Cirkorow')

CREATE TABLE [Pesnia] (
	Id int NOT NULL identity,
	Composition nvarchar(50) NOT NULL,
	Ispolnitel nvarchar(50) NOT NULL,
	Time time NOT NULL,
	Style nvarchar(50) NOT NULL,
	PerformerId int NOT NULL,
	GroupId int NOT NULL,
  CONSTRAINT [PK_Pesnia] PRIMARY KEY CLUSTERED
  (
  [Id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
insert into Pesnia(Composition,Ispolnitel,Time,Style,PerformerId,GroupId) values('Sun','Boby','03:22:43','ROC',2,5)
insert into Pesnia(Composition,Ispolnitel,Time,Style,PerformerId,GroupId) values('Sea','Monatik','06:52:43','ROC',4,1)
insert into Pesnia(Composition,Ispolnitel,Time,Style,PerformerId,GroupId) values('tea','Marly','05:12:43','ROC',6,7)
insert into Pesnia(Composition,Ispolnitel,Time,Style,PerformerId,GroupId) values('bread','Li','04:45:43','ROC',1,2)

select  * from Pesnia

CREATE TABLE [Groups] (
	Id int NOT NULL identity,
	Name nvarchar(50) NOT NULL,
  CONSTRAINT [PK_GROUPS] PRIMARY KEY CLUSTERED
  (
  [Id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
insert into Groups(Name) values('Beatles')
insert into Groups(Name) values('Status Qvo')
insert into Groups(Name) values('Acvarium')
insert into Groups(Name) values('AsDs')
CREATE TABLE [Disks] (
	Id int NOT NULL identity,
	Name nvarchar(50) NOT NULL,
	Quantity int NOT NULL,
	PerformerId int NOT NULL,
	GroupId int NOT NULL,
  CONSTRAINT [PK_DISKS] PRIMARY KEY CLUSTERED
  (
  [Id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
insert into Disks (Name,Quantity,PerformerId,GroupId) values('Beatles',45,6,4)
insert into Disks (Name,Quantity,PerformerId,GroupId) values('Acvarium',16,4,1)
insert into Disks (Name,Quantity,PerformerId,GroupId) values('Status Qvo',18,3,2)
insert into Disks (Name,Quantity,PerformerId,GroupId) values('San',3,4,3)

ALTER TABLE [Сompositions] WITH CHECK ADD CONSTRAINT [Сompositions_fk0] FOREIGN KEY ([PerformerId]) REFERENCES [Performers]([Id])
--ON UPDATE CASCADE
GO
ALTER TABLE [Сompositions] CHECK CONSTRAINT [Сompositions_fk0]
GO
ALTER TABLE [Сompositions] WITH CHECK ADD CONSTRAINT [Сompositions_fk1] FOREIGN KEY ([GroupId]) REFERENCES [Groups]([Id])
--ON UPDATE CASCADE
GO
ALTER TABLE [Сompositions] CHECK CONSTRAINT [Сompositions_fk1]
GO


ALTER TABLE [Disks] WITH CHECK ADD CONSTRAINT [Disks_fk0] FOREIGN KEY ([PerformerId]) REFERENCES [Performers]([Id])
--ON UPDATE CASCADE
GO
ALTER TABLE [Disks] CHECK CONSTRAINT [Disks_fk0]
GO
ALTER TABLE [Disks] WITH CHECK ADD CONSTRAINT [Disks_fk1] FOREIGN KEY ([GroupId]) REFERENCES [Groups]([Id])
--ON UPDATE CASCADE
GO
ALTER TABLE [Disks] CHECK CONSTRAINT [Disks_fk1]
GO

