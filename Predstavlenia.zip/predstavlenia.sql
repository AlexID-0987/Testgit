

--������� 3
--select * from Update_view
--create view Update_view as
--select Composition,Style,Ispolnitel,Time,PerformerId, GroupId from Pesnia

--update Update_view set Composition = 'Fasher' where Ispolnitel = 'Marly'
--4
--delete from Delete_view where Ispolnitel = 'Monatik'
--select * from New_compozition_view

--create view Delete_view as
--select Composition,Style,Ispolnitel,Time,PerformerId, GroupId from Pesnia


--2
--insert into New_compozition_view (Composition,Style,Ispolnitel,Time,PerformerId,GroupId)
--values ('Mama','Classik','Peper','03:45:55',2,5)

--select * from New_compozition_view

--create view New_compozition_view as
--select Composition,Style,Ispolnitel,Time,PerformerId, GroupId from Pesnia



--1
 --select * from New_stile_view

--insert into New_stile_view (Style,Composition,Ispolnitel,Time,PerformerId,GroupId)
--values ('Dshaz','Bit','Peper','03:45:55',2,5)
 
 --create view New_stile_view as
 --select Style,Composition,Ispolnitel,Time,PerformerId, GroupId from Pesnia

 

--select * from New_stile_view

 

--������� 2
--6
--select * from Compositions_view

--create view Compositions_view as
--select Ispolnitel as [Name]   from Pesnia
--where Time = (select max (Time) from Pesnia) 

--5
--select * from Top_popular_view

--create view Top_popular_view as
--select top 3 (Quantity) as [Top],Name from Disks

--4
--select * from Popular_view

--create view Popular_view as
--select max (Quantity) as [Max disk],Name ='Beatles' from Disks


--3
--select * from disk_Beatles_view

--create view disk_Beatles_view as
--select Quantity,Name = 'Beatles' from Disks

--2
--select * from music_compositions_view

--create view music_compositions_view as
--select Composition,Time,Style,Ispolnitel,Name from Pesnia,Disks

--1
--select * 
--from Perfomer_view