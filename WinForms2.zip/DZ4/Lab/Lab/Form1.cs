﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab
{
    public partial class Form1 : Form
    {
        int X { get; set; }
        int Y { get; set; }
        int numStatic { get; set; } = 1;
        
            const int a = 10;
        public Form1()
        {
            InitializeComponent();
            Text = "Forma";
            MouseDown += Form1_MouseDown;
            MouseUp += Form1_MouseUp;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.label1.Location = new System.Drawing.Point(10, 10);
            this.label1.Size = new Size(100, 400);
            this.label1.Text = ("Main label 10x10");
            textBox1.Text = (label1.Width.ToString());
            textBox2.Text = (label1.Height.ToString());
           
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                String message = "";

                message = "You left button mouse";
                MessageBox.Show(message);
               
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                X = e.X;
                Y = e.Y;
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Label label = new Label();
                label.BorderStyle = BorderStyle.Fixed3D;
                
                if (e.X > X && e.Y > Y)
                {
                    label.Location = new Point(X, Y);
                }
                else if (e.X > X && e.Y < Y)
                {
                    label.Location = new Point(X, e.Y);
                }
                else if (e.X < X && e.Y < Y)
                {
                    label.Location = new Point(e.X, e.Y);
                }
                else
                {
                    label.Location = new Point(e.X, Y);
                }
                if (Math.Abs(e.X - X) <= 10 || Math.Abs(e.Y - Y) <= 10)
                {
                    MessageBox.Show("Not «static» 10х10", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    
                    label.Size = new Size(Math.Abs(e.X - X), Math.Abs(e.Y - Y));
                    label.Text = $"{numStatic}";
                    label.ForeColor = Color.White;
                    label.BackColor = Color.Blue;
                    Controls.Add(label);
                    Text = $"Static number №{label.Text} enter!";
                    
                    numStatic++;
                }
            }
            else
            {
                MessageBox.Show("The enter static left mouse", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label2_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                foreach (Label item in Controls)
                {
                    Point location = item.PointToScreen(Point.Empty);
                    if (MousePosition.X > location.X && MousePosition.X < location.X + item.Width && MousePosition.Y > location.Y && MousePosition.Y < location.Y + item.Height)
                    {
                        Text = $"Number №{item.Text}, P {item.Width * item.Height},  Х = {item.Location.X} Y = {item.Location.Y}";
                    }
                }
            }
        }

        private void label2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int numLabel = numStatic;
            if (e.Button == MouseButtons.Left)
            {
                foreach (Label item in Controls)
                {
                    Point location = item.PointToScreen(Point.Empty);
                    if (MousePosition.X > location.X && MousePosition.X < location.X + item.Width && MousePosition.Y > location.Y && MousePosition.Y < location.Y + item.Height)
                    {
                        if (numLabel > Convert.ToInt32(item.Text))
                        {
                            numLabel = Convert.ToInt32(item.Text);
                        }
                    }
                }
            }
            foreach (Label item in Controls)
            {
                if (numLabel == Convert.ToInt32(item.Text))
                {
                    Text = $"Static № {item.Text}remove!";
                    Controls.Remove(item);
                    item.MouseClick -= label2_MouseClick;
                    item.MouseDoubleClick -= label2_MouseDoubleClick;
                }
            }
        }
    }
}
