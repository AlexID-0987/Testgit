﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day_difference
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime dt = new DateTime();
            dt = DateTime.Parse(EnterDate.Text);
            DateTime dayNow = DateTime.Now;
            TimeSpan tempDay = dt - dayNow;
            if (dt < dayNow)
            {
                if (radioButton1.Checked)
                {
                    rezult.Text = (tempDay.TotalDays / 365).ToString();
                }
                if (radioButton2.Checked)
                {
                    rezult.Text = (tempDay.TotalDays / 30).ToString();
                }
                if (radioButton3.Checked)
                {
                    rezult.Text = ((int)tempDay.TotalDays).ToString();
                }
                if (radioButton4.Checked)
                {
                    rezult.Text = ((int)tempDay.TotalMinutes).ToString();
                }
                if (radioButton5.Checked)
                {
                    rezult.Text = ((int)tempDay.TotalSeconds).ToString();
                }
            }
            else
            {
                rezult.Text = "Error!The date has not come yet!";
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.EnterDate.Clear();
            this.rezult.Clear();
        }
    }
}
