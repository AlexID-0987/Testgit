﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mouse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            textBox1.Text="Mouse X:" + e.X.ToString();
            textBox2.Text = "Mouse Y:" + e.Y.ToString();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                label1.Text = this.ClientSize.ToString();
            }
            if (Control.ModifierKeys == Keys.Control && e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                Application.Exit();
            }
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                

                if (e.X < 50 || e.Y < 50 || e.X > this.Width - 50 || e.Y > this.Height - 50)
                {
                    
                    this.Text = "Sone";
                    return;
                }
                else
                {
                    
                    this.Text = "Not Sone";
                    return;
                }

                
            }
            
        }

        private void Form1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            
        }
    }
}
