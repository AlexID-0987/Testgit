﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Random_one
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        

        private void button1_Click(object sender, EventArgs e)
        {
            int a = 0;
            int num=1;
            Random n = new Random();
            int[] size = new int[1];
            string b = textBox2.Text;
            int w = Convert.ToInt32(b);
            
           
            for (int i=0;i<size.Length;i++)
            {
                a = n.Next(1, 2000);
                while (!(size.Contains(a)))
                {
                    size[i] = a;
                    
                }
                textBox1.Text=(a.ToString());
                
            }
            
            //string b = textBox2.Text;
            label1.Text = b;
            //int w = Convert.ToInt32(b);
            
            
                if (a == w)
                {
                   
                    MessageBox.Show("Okkey, you won! Number ");
                    


                }
                else
                {


                
                    MessageBox.Show("You Luzzer!");
                    
                }
                if (w > 2000)
                {
                    MessageBox.Show("Exit diapazone!");
                }
            
            
                if (a != w)
                {
                num++;
                    textBox3.Text = (num.ToString());
                }
            
                
            

        }
        

        public void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
