﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rezume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            MessageBox.Show("Main rezume.");
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            label1.Visible = true; 
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            label2.Visible = true;
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            label2.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            label3.Visible = true;
        }

        private void button3_MouseUp(object sender, MouseEventArgs e)
        {
            label3.Visible = false;
        }

        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            
            label4.Text = "Кол-во 3 :" + label3.Text.Length;
            label5.Text = "Кол-во 2 :" + label2.Text.Length;
            label6.Text = "Кол-во 1 :" + label1.Text.Length;

            
        }
    }
}
