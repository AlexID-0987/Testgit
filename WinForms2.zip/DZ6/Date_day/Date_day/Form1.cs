﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Date_day
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DateTime day = new DateTime();
            textBox2.Text = day.ToString("dddd");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime day = new DateTime();
            day = DateTime.Parse(textBox1.Text);
            textBox2.Text = day.ToString("dddd");
        }
    }
}
