use Sorevnovania

CREATE TABLE [competition] (
	competition_id int NOT NULL identity,
	competition_name nvarchar(50) NOT NULL,
	world_record nvarchar(50) NOT NULL,
	set_date Datetime not NULL,
  CONSTRAINT [PK_COMPETITIONS] PRIMARY KEY CLUSTERED
  (
  [competition_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
insert into competition(competition_name,world_record,set_date) 
values('Michael','International','2016-03-06 12:23:00')
insert into competition(competition_name,world_record,set_date) 
values('Cua','Run','2012-01-12 10:56:00')
insert into competition(competition_name,world_record,set_date) 
values('Joann','Swimming','2019-10-09 07:23:00')
insert into competition(competition_name,world_record,set_date) 
values('Leonid','Barbell','1983-03-06 11:23:00')
insert into competition(competition_name,world_record,set_date) 
values('Nika','Jumping','2010-12-05 12:53:00')
select  * from competition

CREATE TABLE [result] (
	competition_id int NOT NULL identity,
	sportsman_id int NOT NULL,
	result Time NOT NULL,
	city nvarchar(30) not null,
	hold_date Datetime not NULL,
  CONSTRAINT [PK_RESULTS] PRIMARY KEY CLUSTERED
  (
  [competition_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO

insert into result(sportsman_id,result,city,hold_date)
values (2,'00:00:10','Sidney','2020-20-12 13:30:00')
insert into result(sportsman_id,result,city,hold_date)
values (9,'00:00:10','Moskow','2014-12-04 08:33:00')
insert into result(sportsman_id,result,city,hold_date)
values (6,'00:00:12','Kuiv','2020-12-12 17:54:00')
insert into result(sportsman_id,result,city,hold_date)
values (7,'00:00:04','Parish','2014-12-04 06:12:00')

select *from result
CREATE TABLE [sportsman] (
	sportsman_id int NOT NULL identity,
	sportsman_name nvarchar(30) not null,
	rank int not null,
	year_of_birth Date not null,
	personal_record Date not null,
	country nvarchar(30) not null,
	
  CONSTRAINT [PK_SPORTSMANS] PRIMARY KEY CLUSTERED
  (
  [sportsman_id] ASC
  ) WITH (IGNORE_DUP_KEY = OFF)

)
GO
insert into sportsman(sportsman_name,rank,year_of_birth,personal_record,country)
values ('Joann Frenk',2,'1975-12-03','1999-03-11','USA')
insert into sportsman(sportsman_name,rank,year_of_birth,personal_record,country)
values ('Max Bill',2,'1984-03-30','2009-06-23','Italia')
insert into sportsman(sportsman_name,rank,year_of_birth,personal_record,country)
values ('Li Uan',7,'1995-01-23','2010-12-05','Cina')
insert into sportsman(sportsman_name,rank,year_of_birth,personal_record,country)
values ('Den Prus',22,'2001-02-05','2003-02-11','Latvia')

--4
select *from sportsman

--5
select * from competition
--6
select sportsman_name,year_of_birth 
from sportsman
where year_of_birth>='1990-01-01' and year_of_birth<='1990-12-31'
--7
select world_record,set_date
from competition
where set_date>='2010-12-05' and set_date<='2010-15-05'
--8
select distinct result,city,hold_date,c.competition_name,c.world_record
from result,competition as c
where city = 'Moskow' and result = '00:00:10'
--9
select distinct  sp.sportsman_id,sp.sportsman_name,result
from sportsman as sp,result
where result!='00:00:15'
--10
select competition_name,world_record,set_date,result
from competition,result
where result = '00:00:15' and set_date = '2015-02-12 00:00:00'
--11
select r.result,city
from result as r
where result in ('00:00:13','00:00:25','00:00:17','00:00:09')
--12
select sportsman_name,year_of_birth,result
from sportsman,result
where result not in ('00:00:03','00:00:07','00:00:09') and year_of_birth='2000-02-05' 
--13
select hold_date,city
from result
where city like '%M'
--14
select hold_date,city,year_of_birth
from result,sportsman
where city like '%M' and year_of_birth like '%6'
--15
select competition_name,world_record
from competition
where world_record like 'International'
--16
select distinct year_of_birth,sportsman_name
from sportsman
--17
select count(result) as [count]
from result
where hold_date = '2014-12-04 06:12:00'
--18
select max(result) as [res]
from result
where city like('%Moskow')
--19
select min(year_of_birth)
from sportsman
--20
select sportsman_name,result
from sportsman,result
where hold_date='2014-12-04 06:12:00'
--21
select competition_name,world_record,set_date
from competition
join result on result.competition_id=competition.competition_id
where city = 'Moskow' and hold_date ='2014-12-04 08:33:00'
--22
select avg (competition_id)
from competition
where competition_id in (1,2,3,4,5,6,7)
--23
select year_of_birth
from sportsman,result
where city='Moskow' and result>='00:00:05'
--24
select sportsman_name
from sportsman,result,competition
where hold_date>='2014-12-04 08:33:00' 
--25
select 'Sportsmen' + sportsman_name + 'City' + city + 'Record' + world_record
from sportsman,result,competition
--26
select sportsman_name
from sportsman
where year_of_birth >= '2020-01-01' and year_of_birth <='2020-12-31'
--27
select sportsman_name,personal_record,set_date
from sportsman,competition
where personal_record=set_date
--28
select count(sportsman_id)
from sportsman,competition
where sportsman_name like '%Ivanov' and personal_record like '%Regoins'
--29
select world_record,city
from competition,result
where world_record like '%International'
--30
select city
from result,competition
where world_record like '%International'
--31
select *
from competition
where world_record like '%International'
--32
select count(sportsman_name)
from sportsman,competition
where country = 'USA' and world_record ='International'

select count(sportsman_name)
from sportsman,competition
where country = 'Latvia' and world_record ='International'

select count(sportsman_name)
from sportsman,competition
where country = 'Cina' and world_record ='International'

select count(sportsman_name)
from sportsman,competition
where country = 'Italia' and world_record ='International'

--33
update sportsman
set rank=1
from competition
where competition.world_record ='International'
--34
--35

select dateadd(day,4,hold_date)
from result
--36
update sportsman
set country='������'
from competition
where country ='Italia' and rank in (1,2)
--37
update competition
set world_record ='��� � ������������'
from competition
where world_record ='Run' 
--38
select dateadd(second,2,set_date)
from competition
--39
select dateadd(second,-2,set_date)
from competition,result
where set_date='2012-20-05' and result >= '00:00:45'
--40
delete result
from sportsman
where city='Moskow' and year_of_birth='1980-01-01'
--41
delete result
where result ='00:00:20'
--42

delete sportsman
where year_of_birth='2001-02-05'